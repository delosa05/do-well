import logo from "./logo.svg";
import "./App.css";

function App() {
  return <div className="App">Dedi</div>;
}

export default App;
